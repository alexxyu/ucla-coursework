#!/bin/sh

python3 convert.py
