SELECT id
FROM Person
WHERE given_name = 'Marie' AND family_name = 'Curie';
