SELECT DISTINCT country
FROM Affiliation
WHERE affiliation_name = 'CERN';
