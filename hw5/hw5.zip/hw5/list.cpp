void listAll(string path, const Class* c)  // two-parameter overload
{
    if(c != nullptr) {
        cout << path << c->name() << endl;
        for(Class* subclass: c->subclasses()) {
            listAll(path + c->name() + "=>", subclass);
        }
    }
}
